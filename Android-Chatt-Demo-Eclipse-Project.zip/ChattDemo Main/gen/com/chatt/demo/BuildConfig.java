/** Automatically generated file. DO NOT MODIFY */
package com.chatt.demo;

// TODO: Auto-generated Javadoc
/**
 * The Class BuildConfig.
 */
public final class BuildConfig
{

	/** The Constant DEBUG. */
	public final static boolean DEBUG = true;
}