package com.chatt.demo.utils;

/**
 * The Class Const is a single common class to hold all the app Constants.
 */
public class Const
{

	/** The Constant EXTRA_DATA. */
	public static final String EXTRA_DATA = "extraData";
}
